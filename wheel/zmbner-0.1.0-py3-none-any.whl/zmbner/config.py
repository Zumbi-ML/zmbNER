# -*- coding: UTF-8 -*-

import os

this_file_path = os.path.dirname(os.path.realpath(__file__))

RESOURCES_DIR = os.path.join(this_file_path, "resources/")
